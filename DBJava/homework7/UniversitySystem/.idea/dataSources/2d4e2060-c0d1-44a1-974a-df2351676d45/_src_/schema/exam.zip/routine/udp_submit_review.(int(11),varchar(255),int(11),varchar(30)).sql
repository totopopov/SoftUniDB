CREATE PROCEDURE exam.udp_submit_review(IN customer_id  INT, IN review_content VARCHAR(255), IN review_grade INT,
                                        IN airline_name VARCHAR(30))
  BEGIN
DECLARE id INT(11);
IF airline_name NOT IN ( SELECT a.airline_name FROM airlines AS a) THEN
signal sqlstate '45000' set message_text = 'Airline does not exist';
ELSE 
SET id:= (SELECT a.airline_id FROM airlines AS a  WHERE a.airline_name=airline_name);
INSERT INTO  customer_reviews (review_content,review_grade,airline_id,customer_id)
VALUES(review_content,review_grade,id,customer_id);
END IF;
END;
