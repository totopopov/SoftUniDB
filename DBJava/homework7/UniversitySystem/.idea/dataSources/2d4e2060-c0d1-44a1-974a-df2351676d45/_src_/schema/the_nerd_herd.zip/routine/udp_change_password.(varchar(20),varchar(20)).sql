CREATE PROCEDURE the_nerd_herd.udp_change_password(IN email VARCHAR(20), IN password VARCHAR(20))
  BEGIN
IF (SELECT COUNT(c.email)  FROM credentials AS c WHERE c.email=email)<>1 THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "The email does't exist!";
END IF;
UPDATE credentials AS c
SET c.password:=password
WHERE c.email=email;
END;
