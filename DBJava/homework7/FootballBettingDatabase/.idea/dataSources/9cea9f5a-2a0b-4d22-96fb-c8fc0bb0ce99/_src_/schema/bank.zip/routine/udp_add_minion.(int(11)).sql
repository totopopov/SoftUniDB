CREATE PROCEDURE udp_add_minion(IN id INT)
  BEGIN
    START TRANSACTION;

    UPDATE minions as m
    SET m.age=m.age+1 WHERE m.minion_id=id;
    COMMIT;
  END;
