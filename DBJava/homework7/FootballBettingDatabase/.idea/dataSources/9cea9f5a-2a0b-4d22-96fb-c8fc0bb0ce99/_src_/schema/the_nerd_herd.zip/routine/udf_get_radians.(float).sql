CREATE FUNCTION the_nerd_herd.udf_get_radians(degrees FLOAT)
  RETURNS FLOAT
  BEGIN
DECLARE outcome FLOAT;
SET outcome := degrees * PI()/180;
RETURN outcome;
END;
