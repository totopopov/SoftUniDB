CREATE TRIGGER exam.trigger_update
AFTER UPDATE ON exam.flights
FOR EACH ROW
  BEGIN 
IF	NEW.`status`='Arrived' THEN
INSERT INTO arrived_flights (flight_id,arrival_time,origin,destination,passengers)
VALUE(OLD.flight_id, OLD.arrival_time,
(SELECT a.airport_name FROM  airports AS a WHERE a.airport_id=OLD.origin_airport_id),
(SELECT a.airport_name FROM  airports AS a WHERE a.airport_id=OLD.destination_airport_id),
(SELECT COUNT(*) FROM  tickets AS a WHERE a.flight_id=OLD.flight_id));
END IF;
END;
