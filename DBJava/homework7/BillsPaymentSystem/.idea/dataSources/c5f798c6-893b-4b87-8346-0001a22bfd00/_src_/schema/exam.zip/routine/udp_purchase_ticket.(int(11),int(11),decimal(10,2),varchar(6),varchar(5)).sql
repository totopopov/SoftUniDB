CREATE PROCEDURE exam.udp_purchase_ticket(IN customer_id INT, IN flight_id INT, IN ticket_price DECIMAL(10, 2),
                                          IN class       VARCHAR(6), IN seat VARCHAR(5))
  BEGIN
START TRANSACTION;
INSERT INTO tickets(price,
	class ,
	seat ,
	customer_id ,
	flight_id )
VALUES(ticket_price,class,seat,customer_id,flight_id);
UPDATE customer_bank_accounts
SET balance:=balance-ticket_price WHERE customer_id=customer_id;

IF (SELECT cba.balance FROM customer_bank_accounts AS cba WHERE cba.customer_id=customer_id)<0
 THEN
ROLLBACK;
ELSE
COMMIT;
END IF;
END;
