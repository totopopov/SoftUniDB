Sd-salesDB

Pattern Not Completed, however it will be soon;
Drop me an email to send the complete task at totopopov@gmail.com 