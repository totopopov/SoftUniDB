package core;


/**
 * Created by Todor Popov using Lenovo on 23.4.2017 г. at 17:02.
 */
public class DataHandler implements DataHandlerAble {



}
