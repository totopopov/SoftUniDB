package models;

/**
 * Created by Todor Popov using Lenovo on 24.7.2017 г. at 23:36.
 */
public interface UserAble {
}
