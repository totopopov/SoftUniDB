CREATE TRIGGER b_exam_sql.trigger_update
BEFORE INSERT ON b_exam_sql.problems
FOR EACH ROW
  BEGIN 

IF (SELECT LOCATE(' ',NEW.name))=0
THEN 
 SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'The given name is invalid!';
END IF;

IF NEW.points<=0
THEN 
 SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'The problem’s points cannot be less or equal to 0!';
END IF;

IF NEW.tests<=0
THEN 
 SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'The problem’s tests cannot be less or equal to 0!';
END IF;


END;
