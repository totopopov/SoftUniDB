CREATE PROCEDURE b_exam_sql.udp_login(IN username VARCHAR(30), IN password VARCHAR(30))
  BEGIN

IF (SELECT COUNT(u.username) FROM users AS u WHERE u.username=username)<>1
THEN 
 SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Username does not exist!';
END IF;
IF (SELECT COUNT(u.username) FROM users AS u WHERE u.username=username AND u.password=password)<>1
THEN 
 SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Password is incorrect!';
END IF;
IF (SELECT COUNT(liu.username) FROM logged_in_users AS liu WHERE liu.username=username)<>0
THEN 
 SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'User is already logged in!';
END IF;

INSERT INTO logged_in_users()
SELECT * FROM users AS u WHERE u.username=username AND u.password=password;
END;
