CREATE PROCEDURE usp_get_holders_with_balance_higher_than(IN number DECIMAL(19, 4))
  BEGIN
SELECT ah.first_name,ah.last_name
FROM account_holders AS ah
INNER JOIN (SELECT a.account_holder_id, SUM(a.balance) AS balance
FROM accounts AS a
GROUP BY a.account_holder_id) AS bal ON ah.id=bal.account_holder_id
WHERE bal.balance>=number
ORDER BY ah.first_name,ah.last_name;
END;
