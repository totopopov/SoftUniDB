package gamestore.app.entities.models.viewModels;

/**
 * Created by Todor Popov using Lenovo on 2.8.2017 г. at 23:21.
 */
public class GameDtoShopingCart {
    private Long id;
    private String title;
}
