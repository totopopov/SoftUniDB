package gamestore.app.entities;

/**
 * Created by Todor Popov using Lenovo on 2.8.2017 г. at 23:18.
 */
public interface GameAble {
}
