package gamestore.app.entities.enums;

/**
 * Created by Todor Popov using Lenovo on 1.8.2017 г. at 14:58.
 */
public enum UserRole {
    USER,ADMIN;
}
