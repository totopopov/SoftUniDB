package studentsystem.app.services.interfaces;

import studentsystem.app.models.Resource; /**
 * Created by Todor Popov using Lenovo on 26.7.2017 г. at 20:06.
 */

public interface ResourceService {
    void register(Resource author);
}
