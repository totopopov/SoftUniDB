package softuni.users.services.api;

import softuni.users.entities.Town;


public interface TownService {

    void persist(Town town);
}
