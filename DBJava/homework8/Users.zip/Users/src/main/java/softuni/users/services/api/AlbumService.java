package softuni.users.services.api;

import softuni.users.entities.Album;


public interface AlbumService {

    void persist(Album album);
}
