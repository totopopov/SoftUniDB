package softuni.users.services.api;

import softuni.users.entities.Picture;


public interface PictureService {

    void persist(Picture picture);
}
