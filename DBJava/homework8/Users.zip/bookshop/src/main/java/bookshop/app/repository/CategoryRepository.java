package bookshop.app.repository;

import bookshop.app.models.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by Todor Popov using Lenovo on 25.7.2017 г. at 16:59.
 */

@Repository
public interface CategoryRepository extends JpaRepository<Category,Long>{
}
