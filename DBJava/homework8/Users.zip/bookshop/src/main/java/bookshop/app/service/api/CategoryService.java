package bookshop.app.service.api;


import bookshop.app.models.Category;

/**
 * Created by Todor Popov using Lenovo on 25.7.2017 г. at 17:01.
 */

public interface CategoryService {
    void register(Category category);
}
