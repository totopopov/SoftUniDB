package bookshop.app.models;

import org.springframework.stereotype.Component;


/**
 * Created by Todor Popov using Lenovo on 25.7.2017 г. at 17:26.
 */
public enum  EditionType {
    NORMAL, PROMO, GOLD;
}
