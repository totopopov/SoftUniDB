package bookshop.app;

import bookshop.app.models.*;
import bookshop.app.service.api.AuthorService;
import bookshop.app.service.api.BookService;
import bookshop.app.service.api.CategoryService;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.io.*;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Todor Popov using Lenovo on 25.7.2017 г. at 17:09.
 */

@Component
public class ConsoleRunner implements CommandLineRunner{



    private final BookService bookService;

    private final CategoryService categoryService;

    private final AuthorService authorService;

    @Autowired
    public ConsoleRunner(AuthorService authorService, BookService bookService, CategoryService categoryService) {
        this.bookService = bookService;
        this.categoryService = categoryService;
        this.authorService = authorService;
    }


    @Override
    public void run(String... strings) throws Exception {

        System.out.println("Database created");
        //task 1 and task 2
//        try {
//            seedDatabase();
//            System.out.println("Database seeded");
//        }catch (IOException| ParseException e){
//            System.out.println(e.getMessage());
//        }

        //task 3
//        task3();

        //task 4
        section4();


    }

    private void section4() {
        List<Book> books = (List<Book>) bookService.findall();
        List<Book> threeBooks = books.subList(0, 3);

        threeBooks.get(0).getRelatedBooks().add(threeBooks.get(1));
        threeBooks.get(1).getRelatedBooks().add(threeBooks.get(0));
        threeBooks.get(0).getRelatedBooks().add(threeBooks.get(2));
        threeBooks.get(2).getRelatedBooks().add(threeBooks.get(0));

        //save related books to the database

        for (Book book : threeBooks) {
            bookService.register(book);
        }

        for (Book book : threeBooks) {
            System.out.printf("--%s\n", book.getTitle());
            for (Book relatedBook : book.getRelatedBooks()) {
                System.out.println(relatedBook.getTitle());
            }
        }
    }

    private void task3() {
        List<Book> bookByReleaseDateYearAFter = bookService.findBookByReleaseDateYearAFter(2000);
        for (Book book : bookByReleaseDateYearAFter) {
            System.out.println(book.getTitle());
        }

        List<Author> authors=authorService.findAuthorsByReleaseDateBefore(1990);
        for (Author author : authors) {
            System.out.println(String.format("%s %s  with id: %d",author.getFirstName(),
                    author.getLastName(),author.getId()));
        }

        List<Author> authors1ByBook=authorService.findAllOrderByBookCount();
        for (Author author : authors1ByBook) {
            System.out.println(String.format("%s %s %d",author.getFirstName()
            ,author.getLastName(),author.getBooks().size()));
        }

        List<Book> books=bookService.findBooksByAuthorOrdered("George","Powell");

        for (Book book : books) {
            System.out.println(String.format("%s %s %d",book.getTitle(),
                    book.getReleaseDate(),book.getCopies()));
        }
    }

    private void seedDatabase() throws IOException, ParseException {

        List<Author> authors=new ArrayList<>();
        List<Category> categories = new ArrayList<>();
        getAuthors(authors);
        getCategories(categories);
        seedBooks(authors,categories);

    }

    private void seedBooks(List<Author> authors,List<Category> categories) throws IOException, ParseException {
        Random random =new Random();
        StringBuilder sb = new StringBuilder();
        InputStream source=getClass().getResourceAsStream("/books.txt");
        BufferedReader booksReader = new BufferedReader(new InputStreamReader(source));
        String line = booksReader.readLine();
        while((line = booksReader.readLine()) != null){
            String[] data = line.split("\\s+");
            int authorIndex = random.nextInt(authors.size());
            Author author = authors.get(authorIndex);

            EditionType editionType = EditionType.values()[Integer.parseInt(data[0])];
            SimpleDateFormat formatter = new SimpleDateFormat("d/M/yyyy");
            Date releaseDate = formatter.parse(data[1]);
            Long copies = Long.parseLong(data[2]);
            BigDecimal price = new BigDecimal(data[3]);
            AgeRestriction ageRestriction = AgeRestriction.values()[Integer.parseInt(data[4])];
            StringBuilder titleBuilder = new StringBuilder();
            for (int i = 5; i < data.length; i++) {
                titleBuilder.append(data[i]).append(" ");
            }
            titleBuilder.delete(titleBuilder.lastIndexOf(" "), titleBuilder.lastIndexOf(" "));
            String title = titleBuilder.toString();

            Book book = new Book();
            book.setAuthor(author);
            book.setEditionType(editionType);
            book.setReleaseDate(releaseDate);
            book.setCopies(copies);
            book.setPrice(price);
            book.setAgeRestriction(ageRestriction);
            book.setTitle(title);
            sb.append(title).append(" written by ");
            sb.append(author.getFirstName()).append(" ");
            sb.append(author.getLastName()).append(" targeting");
            sb.append(ageRestriction.name()).append(". The style is ");
            sb.append(editionType.name()).append(". ");
            sb.append(copies).append(" were printed worldwide.");
            book.setDescription(sb.toString());
            sb.setLength(0);

            int categoryNumber = random.nextInt(categories.size());

            int categoryCount=0;

            Set<Category> categorySet = new HashSet<>();
            while (categoryCount<categoryNumber){
                Category category=categories.get(random.nextInt(categoryNumber));
                if (!categorySet.contains(category)){
                    categorySet.add(category);
                    categoryCount++;
                }
            }
            book.setCategories(categorySet);
            bookService.register(book);
        }
    }

    private void getCategories(List<Category> categories) throws IOException {
        InputStream source=getClass().getResourceAsStream("/categories.txt");
        BufferedReader categoryReader = new BufferedReader(new InputStreamReader(source));
        String categoryLIne = categoryReader.readLine();
        while((categoryLIne = categoryReader.readLine()) != null) {
            String[] data = categoryLIne.split("\\s+");

            String categoryName=data[0];

            Category category=new Category(categoryName);
            categories.add(category);
            categoryService.register(category);
        }
    }
    private void getAuthors(List<Author> authors) throws IOException {
        InputStream source=getClass().getResourceAsStream("/authors.txt");
//        BufferedReader authorsReader = new BufferedReader(new FileReader("/authors.txt"));
        BufferedReader authorsReader = new BufferedReader(new InputStreamReader(source));
        String authorLine = authorsReader.readLine();
        while((authorLine = authorsReader.readLine()) != null) {
            String[] data = authorLine.split("\\s+");

            String firstName=null;
            String secondName=null;

            if (data.length==2){
                firstName=data[0];
                secondName=data[1];
            }else {
                secondName=data[0];
            }

            Author author=new Author(firstName,secondName);
            authors.add(author);
            authorService.register(author);
        }
    }
}
