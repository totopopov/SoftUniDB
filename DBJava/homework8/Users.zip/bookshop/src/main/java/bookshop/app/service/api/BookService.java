package bookshop.app.service.api;

import bookshop.app.models.Author;
import bookshop.app.models.Book;


import java.util.List;

/**
 * Created by Todor Popov using Lenovo on 25.7.2017 г. at 17:01.
 */

public interface BookService {
    void register(Book book);

    List<Book> findBookByReleaseDateYearAFter(int year);

    List<Book> findBooksByAuthorOrdered(String firstName,String lastName);

    List<Book> findall();
}
