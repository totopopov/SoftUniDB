package bookshop.app.service.impl;

import bookshop.app.models.Author;
import bookshop.app.models.Book;
import bookshop.app.repository.BookRepository;
import bookshop.app.service.api.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

/**
 * Created by Todor Popov using Lenovo on 25.7.2017 г. at 17:03.
 */

@Service
@Transactional
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;


    @Autowired
    public BookServiceImpl(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public void register(Book book){
        bookRepository.saveAndFlush(book);
    }

    @Override
    public List<Book> findBookByReleaseDateYearAFter(int year) {
        return bookRepository.findBookByReleaseDateYearAFter(year);
    }

    @Override
    public List<Book> findBooksByAuthorOrdered(String firstName,String lastName) {
        return this.bookRepository.findBooksByAuthorFirstNameAndAuthorLastNameOrderByReleaseDateDescTitleAsc(firstName,lastName);
    }

    @Override
    public List<Book> findall() {
        return this.bookRepository.findAll();
    }


}
