package bookshop.app.models;

import org.springframework.stereotype.Component;

/**
 * Created by Todor Popov using Lenovo on 25.7.2017 г. at 18:14.
 */
public enum AgeRestriction {
    MINOR, TEEN, ADULT;
}
