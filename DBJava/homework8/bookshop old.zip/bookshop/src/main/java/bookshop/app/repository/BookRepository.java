package bookshop.app.repository;

import bookshop.app.models.Author;
import bookshop.app.models.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * Created by Todor Popov using Lenovo on 25.7.2017 г. at 16:57.
 */
@Service
public interface BookRepository extends JpaRepository<Book,Long> {

    @Query("SELECT b FROM Book AS b WHERE YEAR(b.releaseDate)>:year")
    List<Book> findBookByReleaseDateYearAFter(@Param("year") int year);

    List<Book> findBooksByAuthorFirstNameAndAuthorLastNameOrderByReleaseDateDescTitleAsc(String author_firstName, String author_lastName);


}
