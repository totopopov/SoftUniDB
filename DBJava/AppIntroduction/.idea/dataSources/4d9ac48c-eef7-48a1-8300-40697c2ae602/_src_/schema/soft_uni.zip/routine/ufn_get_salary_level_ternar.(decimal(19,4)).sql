CREATE FUNCTION soft_uni.ufn_get_salary_level_ternar(salary DECIMAL(19, 4))
  RETURNS VARCHAR(10)
  BEGIN
DECLARE outcome VARCHAR(10);
SET outcome:=IF(salary<30000,'Low',IF(salary<=50000,'Average','High'));
RETURN outcome;
END;
