CREATE FUNCTION soft_uni.ufn_is_word_comprised(set_of_letters VARCHAR(20), word VARCHAR(25))
  RETURNS INT
  BEGIN
DECLARE outcome INT DEFAULT 0;
DECLARE i INT DEFAULT 0;
WHILE (i<CHARACTER_LENGTH(word)) DO
SET outcome:=outcome+IF(INSTR(set_of_letters,SUBSTRING(word,i+1,1))>0,1,0);
SET i:=i+1;
END WHILE;
RETURN IF(outcome=CHARACTER_LENGTH(word),1,0);
END;
