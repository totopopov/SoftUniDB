CREATE VIEW soft_uni.v_hr_result_set AS
  SELECT
    concat(`soft_uni`.`employees`.`first_name`, ' ', `soft_uni`.`employees`.`last_name`) AS `Full Name`,
    `soft_uni`.`employees`.`salary`                                                      AS `salary`
  FROM `soft_uni`.`employees`
  ORDER BY `soft_uni`.`employees`.`department_id`;
