CREATE PROCEDURE soft_uni.usp_get_employees_from_town(IN town_name VARCHAR(20))
  BEGIN
SELECT e.first_name,e.last_name FROM employees AS e
INNER JOIN addresses AS a ON a.address_id=e.address_id
INNER JOIN towns AS t ON a.town_id=t.town_id
WHERE t.name=town_name
ORDER BY e.first_name,e.last_name;
END;
