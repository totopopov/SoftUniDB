CREATE FUNCTION soft_uni.ufn_get_salary_level(salary DECIMAL(19, 4))
  RETURNS VARCHAR(10)
  BEGIN
DECLARE outcome VARCHAR(10);
IF salary<30000 THEN
SET outcome :='Low';
ELSEIF salary<=50000 THEN 
SET outcome:='Average';
ELSEIF salary<=50000 THEN 
SET outcome ='High';
END IF;
RETURN outcome;
END;
