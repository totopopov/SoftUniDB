CREATE FUNCTION ufn_calculate_future_value(sumOfM DECIMAL(19, 4), interest DECIMAL(19, 4), years DECIMAL(19, 4))
  RETURNS DECIMAL(19, 2)
  BEGIN
DECLARE outcome DECIMAL(19,4) DEFAULT 0;
SET outcome:= sumOfM*POWER((1+interest),years);
RETURN outcome;
END;
