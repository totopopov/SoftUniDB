package telephony;

/**
 * Created by Todor Popov using Lenovo on 4.7.2017 г. at 19:08.
 */
public interface Browsing {
    String Browse(String URL);
}
