package border;



/**
 * Created by Todor Popov using Lenovo on 4.7.2017 г. at 20:45.
 */
public interface Citizen extends Identifyable,Birthdatable {
    String getName();
}
