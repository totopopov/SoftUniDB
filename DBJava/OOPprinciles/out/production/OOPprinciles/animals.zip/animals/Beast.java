package animals;

/**
 * Created by Todor Popov using Lenovo on 6.7.2017 г. at 19:27.
 */
public interface Beast {
    String makeSound();
}
