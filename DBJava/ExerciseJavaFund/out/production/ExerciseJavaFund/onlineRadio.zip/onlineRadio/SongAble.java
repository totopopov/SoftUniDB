package onlineRadio;

/**
 * Created by Todor Popov using Lenovo on 7.7.2017 г. at 18:39.
 */
public interface SongAble {
    int getDuration();
}
