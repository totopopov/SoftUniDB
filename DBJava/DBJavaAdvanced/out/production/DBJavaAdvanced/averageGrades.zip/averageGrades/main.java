package averageGrades;

import java.util.*;

/**
 * Created by Todor Popov using Lenovo on 8.7.2017 г. at 14:42.
 */
public class main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int numberStudent=Integer.parseInt(scanner.nextLine());

        List<Student>data=new LinkedList<>();

        for (int i = 0; i < numberStudent; i++) {

            String[] input=scanner.nextLine().split("\\s+");


            Student student=new Student(input[0],
                    Arrays.stream(input).skip(1).mapToDouble(Double::parseDouble).toArray());

            data.add(student);



        }


        data.stream().filter(s->s.getAverageGrade()>5)
                .sorted(Comparator.comparing(Student::getName).reversed().thenComparingDouble(Student::getAverageGrade).reversed())
                .forEach(System.out::println);
    }
}
