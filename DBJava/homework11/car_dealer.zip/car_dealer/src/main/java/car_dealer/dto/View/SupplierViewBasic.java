package car_dealer.dto.View;

/**
 * Created by Todor Popov using Lenovo on 7.8.2017 г. at 22:03.
 */
public class SupplierViewBasic {

    private Long id;

    public SupplierViewBasic() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
