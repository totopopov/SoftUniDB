package person;

/**
 * Created by Todor Popov using Lenovo on 4.7.2017 г. at 18:29.
 */
public interface Person {
    String getName();
    int  getAge();
}
