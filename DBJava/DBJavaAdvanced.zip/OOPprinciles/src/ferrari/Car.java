package ferrari;

/**
 * Created by Todor Popov using Lenovo on 4.7.2017 г. at 18:56.
 */
public interface Car {
    String getDriversName();
    String getModel();
    String useBreaks();
    String useGas();
}
