package telephony;

/**
 * Created by Todor Popov using Lenovo on 4.7.2017 г. at 19:07.
 */
public interface Calling {
    String Call(String number);
}
