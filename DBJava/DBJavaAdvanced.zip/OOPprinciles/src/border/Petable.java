package border;

/**
 * Created by Todor Popov using Lenovo on 4.7.2017 г. at 21:05.
 */
public interface Petable extends Birthdatable{
    String getName();
}
