package border;

/**
 * Created by Todor Popov using Lenovo on 4.7.2017 г. at 20:58.
 */
public interface Birthdatable {
   String getDate();
}
