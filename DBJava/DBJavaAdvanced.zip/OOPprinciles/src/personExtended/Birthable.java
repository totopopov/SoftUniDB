package personExtended;

/**
 * Created by Todor Popov using Lenovo on 4.7.2017 г. at 18:45.
 */
public interface Birthable {
 String getBirthdate();
}
