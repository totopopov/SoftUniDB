import java.util.Random;

/**
 * Created by Todor Popov using Lenovo on 29.6.2017 г. at 20:59.
 */
public class testing {
    public static void main(String[] args) {

        Random random= new Random();

        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));
        System.out.println(random.nextInt(15));


    }
}
