import java.util.Scanner;

/**
 * Created by Todor Popov using Lenovo on 9.7.2017 г. at 16:56.
 */
public class reverseSecond {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println(new StringBuilder(scanner.nextLine()).reverse());

    }
}
