import java.util.Scanner;

/**
 * Created by Todor Popov using Lenovo on 9.7.2017 г. at 14:42.
 */
public class BooleanVar {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println(scanner.nextLine().equals("True")?"Yes":"No");

    }
}
