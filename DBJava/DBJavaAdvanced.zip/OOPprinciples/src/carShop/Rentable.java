package carShop;

/**
 * Created by Todor Popov using Lenovo on 3.7.2017 г. at 16:44.
 */
public interface Rentable extends Car{

    int getMinRentDay();
    double getPricePerDay();

}
