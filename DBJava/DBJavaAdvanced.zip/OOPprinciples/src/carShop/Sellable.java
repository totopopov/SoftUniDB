package carShop;

/**
 * Created by Todor Popov using Lenovo on 3.7.2017 г. at 16:34.
 */
public interface Sellable extends Car {

    double getPrice();

}
