package carShop;

/**
 * Created by Todor Popov using Lenovo on 3.7.2017 г. at 16:19.
 */
public interface Car {
        int Tires=4;

        String getModel();
        String getColor();
        Integer getHorsePower();

}
