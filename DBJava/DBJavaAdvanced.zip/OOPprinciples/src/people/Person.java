package people;

/**
 * Created by Todor Popov using Lenovo on 3.7.2017 г. at 16:48.
 */
public interface Person {
    String getName();
    String sayHello();
}
