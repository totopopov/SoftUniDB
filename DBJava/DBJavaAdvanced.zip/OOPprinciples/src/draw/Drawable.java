package draw;

public interface Drawable {
   void draw();
}
