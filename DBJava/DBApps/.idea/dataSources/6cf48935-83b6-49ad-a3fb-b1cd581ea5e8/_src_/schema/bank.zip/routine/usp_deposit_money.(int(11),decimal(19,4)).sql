CREATE PROCEDURE usp_deposit_money(IN account_id INT, IN money_amount DECIMAL(19, 4))
  BEGIN
START TRANSACTION;
UPDATE accounts AS a SET a.balance= a.balance+money_amount WHERE a.id=account_id;
IF money_amount < 0.0 THEN ROLLBACK;
ELSEIF (SELECT COUNT(a.id) FROM accounts AS a WHERE a.id=account_id) <> 1 THEN ROLLBACK;
END IF;
COMMIT;
END;
