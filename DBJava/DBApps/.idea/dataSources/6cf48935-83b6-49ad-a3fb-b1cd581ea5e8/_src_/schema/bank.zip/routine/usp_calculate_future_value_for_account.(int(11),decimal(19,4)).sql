CREATE PROCEDURE usp_calculate_future_value_for_account(IN account_id INT, IN interest DECIMAL(19, 4))
  BEGIN
SELECT a.id, ah.first_name, ah.last_name, a.balance, ufn_calculate_future_value(a.balance,interest,5)  FROM accounts AS a 
INNER JOIN account_holders AS ah ON ah.id=a.account_holder_id
WHERE a.id=account_id;
END;
