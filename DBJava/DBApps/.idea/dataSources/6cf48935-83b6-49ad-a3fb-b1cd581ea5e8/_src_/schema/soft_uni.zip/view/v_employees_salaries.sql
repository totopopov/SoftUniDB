CREATE VIEW soft_uni.v_employees_salaries AS
  SELECT
    `soft_uni`.`employees`.`first_name` AS `first_name`,
    `soft_uni`.`employees`.`last_name`  AS `last_name`,
    `soft_uni`.`employees`.`salary`     AS `salary`
  FROM `soft_uni`.`employees`;
