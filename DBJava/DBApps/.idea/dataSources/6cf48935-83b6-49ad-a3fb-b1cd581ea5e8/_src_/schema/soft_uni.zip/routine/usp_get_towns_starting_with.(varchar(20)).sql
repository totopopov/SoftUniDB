CREATE PROCEDURE soft_uni.usp_get_towns_starting_with(IN town_letter VARCHAR(20))
  BEGIN
SELECT t.name FROM towns AS t 
WHERE LEFT(t.name,1)=town_letter
ORDER BY t.name;
END;
