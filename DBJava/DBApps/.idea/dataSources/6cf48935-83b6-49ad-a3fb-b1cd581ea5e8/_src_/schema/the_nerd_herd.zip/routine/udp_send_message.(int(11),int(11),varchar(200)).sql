CREATE PROCEDURE the_nerd_herd.udp_send_message(IN user_id INT, IN chat_id INT, IN content VARCHAR(200))
  BEGIN
IF (SELECT COUNT(u.id) FROM users AS u WHERE u.id=user_id)<>1 THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "There is no chat with that user!";
END IF;
INSERT INTO messages(content,sent_on,chat_id,user_id)
VALUES(content,'2016-12-15',chat_id,user_id);
END;
