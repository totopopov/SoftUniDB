CREATE TRIGGER the_nerd_herd.any_trigger
AFTER DELETE ON the_nerd_herd.messages
FOR EACH ROW
  BEGIN 
INSERT INTO messages_log(content,sent_on,chat_id,user_id)
VALUES(OLD.content,OLD.sent_on,OLD.chat_id,OLD.user_id);
END;
